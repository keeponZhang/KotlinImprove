package com.keepon.kotlin.chapter5

/**
 * createBy	 keepon
 */

//一个Lambda表达式把一小段行为进行编码，你能把它当做值到处传递，
//它可以被独立地声明并存储到一个变量中，但是最常见的还是直接声明它并传递给函数，
//下面是一个Lambda表达式的语法，->前为 参数，后为函数体，始终用花括号包围。
//
//{x : Int, y : Int -> x + y}