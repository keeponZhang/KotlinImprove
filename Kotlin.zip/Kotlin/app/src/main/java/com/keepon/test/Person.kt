package com.keepon.test

open class Person(private var age: Int) {
}