package com.keepon.kotlin.chapter6

/**
 * createBy	 keepon
 */
//Java的类型系统是不支持可空性的，那么当你混合使用Kotlin和Java时会发生什么呢？