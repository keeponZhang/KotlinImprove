package com.keepon.kotlin.chapter2

/**
 * createBy	 keepon
 */
fun main(args: Array<String>) {
    val  list = listOf<Int>(1,3,4)
    joinToString(list)
    kotlinFunc2()
}


