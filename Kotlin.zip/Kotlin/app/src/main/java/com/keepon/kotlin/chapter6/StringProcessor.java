package com.keepon.kotlin.chapter6;

public interface StringProcessor {
    void process(String value);
}