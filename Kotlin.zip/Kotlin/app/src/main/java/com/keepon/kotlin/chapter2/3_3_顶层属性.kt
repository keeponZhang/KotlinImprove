package com.keepon.kotlin.chapter2

/**
 * createBy	 keepon
 */
//不可变
val kotlinVal = "kotlinValue"

//可变
var kotlinVar = "kotlinVariable"
//常量
const val kotlinConst = "kotlinConst"
