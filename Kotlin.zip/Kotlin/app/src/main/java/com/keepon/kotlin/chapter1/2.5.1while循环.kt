package com.keepon.kotlin.chapter1

/**
 * createBy	 keepon
 */

//kotlin和Java一样，有while循环和do-while循环，它们的语法和Java中相应的循环完全一致。