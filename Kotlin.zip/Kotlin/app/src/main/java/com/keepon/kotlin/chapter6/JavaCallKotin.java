package com.keepon.kotlin.chapter6;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * createBy	 keepon
 */
public class JavaCallKotin {
    public static void nullFunC(@Nullable String s){

    }
    public static void nonnullFunC(@NotNull String s){

    }
    public static void nonAnnotationFunC(String s){

    }
}
