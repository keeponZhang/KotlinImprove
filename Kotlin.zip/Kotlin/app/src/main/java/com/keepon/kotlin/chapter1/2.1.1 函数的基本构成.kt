package com.keepon.kotlin.chapter1

/**
 * createBy	 keepon
 */
//在Kotlin中，函数的基本结构由四个部分构成：
//
//函数名称
//参数列表
//返回类型
//函数体
//函数的声明以关键字 fun 开始，函数名称 紧随其后，接下来是括号括起来的 参数列表，参数列表的后面跟着 返回类型，返回类型和参数列表之间用冒号隔开，最后是函数体。
fun max(a:Int ,b:Int):Int{
    return 2;
}