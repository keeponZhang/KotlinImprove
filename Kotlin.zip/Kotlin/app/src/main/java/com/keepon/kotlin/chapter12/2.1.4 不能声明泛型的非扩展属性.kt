package com.keepon.kotlin.chapter12

/**
 * createBy	 keepon
 */
//普通（非扩展）属性 不能拥有类型参数，不能在一个类型的属性中存储多个不同类型的值，因此 声明泛型非扩展函数没有任何意义。


















