package com.keepon.kotlin.chapter4;

/**
 * createBy	 keepon
 */
public class JavaCallKolin {
    //在 Java 中使用 Kotlin 对象
    public void test(){
        Person.INSTANCE.getName();
    }

}
