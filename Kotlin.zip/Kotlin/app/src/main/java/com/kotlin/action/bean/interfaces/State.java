package com.kotlin.action.bean.interfaces;

import java.io.Serializable;

/**
 * createBy keepon
 */
public interface State extends Serializable {
}
