package com.kotlin.action.bean.javacall;

/**
 * createBy keepon
 */
public class JavaStatic {
    public static void javaStaticMethod(){
        System.out.println("JavaStatic javaStaticMethod ");
    }
}
