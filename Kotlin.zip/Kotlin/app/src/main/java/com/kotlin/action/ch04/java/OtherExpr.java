package com.kotlin.action.ch04.java;

import ch04.ex1_5_2_SealedClasses1.Expr;

/**
 * createBy keepon
 */
// public class OtherExpr extends Expr {
//   //java是不能继承密封类的，因为密封类的构造函数是private
//     public OtherExpr(){
//         super();
//     }
// }
