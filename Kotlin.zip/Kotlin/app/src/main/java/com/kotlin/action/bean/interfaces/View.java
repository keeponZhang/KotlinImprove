package com.kotlin.action.bean.interfaces;

/**
 * createBy keepon
 */
public interface View {
    State getCurrentState();
    State restorState();
}
