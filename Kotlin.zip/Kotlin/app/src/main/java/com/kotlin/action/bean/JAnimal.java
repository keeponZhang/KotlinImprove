package com.kotlin.action.bean;

/**
 * createBy keepon
 */
public class JAnimal {
    private String name;

    public JAnimal(String name) {
        this.name = name;
    }
}
