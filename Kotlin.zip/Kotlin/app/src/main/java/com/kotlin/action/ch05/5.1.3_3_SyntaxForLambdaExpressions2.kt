package ch05.ex1_3_3_SyntaxForLambdaExpressions2

fun main(args: Array<String>) {
//    run里面会调用lambda表达式
    run { println(42) }
}
