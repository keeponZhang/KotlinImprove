package com.kotlin.action.ch04.java;

/**
 * createBy keepon
 */
class Animal {
    protected String name;

}
//下面会报错，在java中，类不能用private修饰
// private class Animal2 {
//     protected String name;
// }