package ch05.ex2_1_3_FilterMap2

fun main(args: Array<String>) {
    val list = listOf(1, 2, 3, 4)
    println(list.map { it * it })
    //[1, 4, 9, 16]
}
