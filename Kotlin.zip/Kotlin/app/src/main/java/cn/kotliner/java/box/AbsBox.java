package cn.kotliner.java.box;

import java.util.Map;

/**
 * Created by benny on 5/28/17.
 */
public abstract class AbsBox implements Map<Integer, String> {

    public String get(Object key) {
        return null;
    }
}
