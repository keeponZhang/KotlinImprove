package cn.kotliner.kotlin.collections

/**
 * Created by benny on 5/28/17.
 */
object ListTest{
    val list = listOf(1,3,4)
}