package cn.kotliner.kotlin.kapt.config

/**
 * Created by benny on 12/11/16.
 */
object Settings {

    const val DEBUG = true

}