package cn.kotliner.java.box;

/**
 * Created by benny on 5/28/17.
 */
public interface BoxIf1 {
    String get(int key);

    String get(Integer key);
}
