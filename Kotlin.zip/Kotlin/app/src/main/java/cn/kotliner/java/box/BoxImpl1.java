package cn.kotliner.java.box;

/**
 * Created by benny on 5/28/17.
 */
public class BoxImpl1 implements BoxIf1{

    public String get(int key) {
        return null;
    }

    public String get(Integer key) {
        return null;
    }
}
